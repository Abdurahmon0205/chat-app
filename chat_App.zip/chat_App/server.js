const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
    if (req.url === '/' || req.url === '/index.html') {
        fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
            if (err) {
                res.writeHead(500);
                return res.end('Xato: Fayl topilmadi');
            }
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data);
        });
    } else if (req.url === '/styles.css') {
        fs.readFile(path.join(__dirname, 'styles.css'), (err, data) => {
            if (err) {
                res.writeHead(500);
                return res.end('Xato: Fayl topilmadi');
            }
            res.writeHead(200, { 'Content-Type': 'text/css' });
            res.end(data);
        });
    } else {
        res.writeHead(404);
        res.end('Sahifa topilmadi');
    }
});

const wss = new WebSocket.Server({ server });
const clients = new Map();

wss.on('connection', (ws) => {
    ws.on('message', (message) => {
        const data = JSON.parse(message);

        if (data.type === 'join') {
            clients.set(ws, data.username);
            broadcast({ type: 'message', username: 'Server', message: `${data.username} chatga qo'shildi`, id: Date.now() });
        } else if (data.type === 'message') {
            broadcast({ type: 'message', username: data.username, message: data.message, id: data.id });
        } else if (data.type === 'delete') {
            broadcast({ type: 'delete', id: data.id });
        }
    });

    ws.on('close', () => {
        const username = clients.get(ws);
        clients.delete(ws);
        if (username) {
            broadcast({ type: 'message', username: 'Server', message: `${username} chatdan chiqdi`, id: Date.now() });
        }
    });
});

function broadcast(message) {
    clients.forEach((_, client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
        }
    });
}

const port = process.env.PORT || 3000; // Glitch dinamik portni ishlatadi
server.listen(port, () => {
    console.log(`Server ${port}-portda ishlamoqda...`);
});